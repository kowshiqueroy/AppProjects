package com.example.duste;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class FirebaseLogin extends AppCompatActivity {

    EditText e,p;
    int a=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_login);




    }

    public void enter(View view) {




        e=findViewById(R.id.e);
        p=findViewById(R.id.p);
         if (TextUtils.isEmpty(e.getText().toString()) || TextUtils.isEmpty(p.getText().toString()) )

         {
             Toast.makeText(getApplicationContext(), "Error Username/Password", Toast.LENGTH_SHORT).show();

         }

         else{


             FirebaseDatabase database = FirebaseDatabase.getInstance();
             DatabaseReference myRef = database.getReference("user");


          //   myRef.child(e.getText().toString().toUpperCase()).setValue(p.getText().toString());


             // Read from the database
             myRef.child(e.getText().toString().toUpperCase()).addValueEventListener(new ValueEventListener() {
                 @Override
                 public void onDataChange(DataSnapshot dataSnapshot) {
                     // This method is called once with the initial value and again
                     // whenever data at this location is updated.
                     String value = dataSnapshot.getValue(String.class);
                     Log.d("FB", "Value is: " + value);

                     if (Objects.equals(value, p.getText().toString())) {

                         Toast.makeText(getApplicationContext(), "Succefully Loged in", Toast.LENGTH_SHORT).show();
a=2;
                         startActivity(new Intent(FirebaseLogin.this, StatusSearch.class));

                     }
                     else {

if (Objects.equals(value, null)) {

    a=1;

}
                     }


                     if (a==1){

                         FirebaseDatabase database2 = FirebaseDatabase.getInstance();
                         DatabaseReference myRef2 = database2.getReference("user");


                         myRef2.child(e.getText().toString().toUpperCase()).setValue(p.getText().toString());
                         Toast.makeText(getApplicationContext(), "Succefully Singed in", Toast.LENGTH_SHORT).show();

                         startActivity(new Intent(FirebaseLogin.this, StatusSearch.class));

                     }

                     else if (a==0) {

                         Toast.makeText(getApplicationContext(), "Password Error", Toast.LENGTH_SHORT).show();

                     }

                 }

                 @Override
                 public void onCancelled(DatabaseError error) {
                     // Failed to read value



                     Log.w("FB", "Failed to read value.", error.toException());

                     FirebaseDatabase database2 = FirebaseDatabase.getInstance();
                     DatabaseReference myRef2 = database2.getReference("user");


                     myRef2.child(e.getText().toString().toUpperCase()).setValue(p.getText().toString());
                     Toast.makeText(getApplicationContext(), "Succefully Singed in", Toast.LENGTH_SHORT).show();

                     startActivity(new Intent(FirebaseLogin.this, StatusSearch.class));


                 }


             });








         }


    }
}