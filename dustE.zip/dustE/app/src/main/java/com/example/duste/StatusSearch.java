package com.example.duste;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class StatusSearch extends AppCompatActivity {

    EditText a,el;
    TextView t,lf,tf;
    int tfFlag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_search);
    }

    public void SV(View view) {

        a=findViewById(R.id.DU);
        t=findViewById(R.id.SV);
        lf=findViewById(R.id.lf);
        tf=findViewById(R.id.tf);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(a.getText().toString());
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("TAG", "Value is: " + value);
                t.setText(value);
                 if (! Objects.requireNonNull(value).contains("Not")) {

                     SimpleDateFormat sdf = new SimpleDateFormat("'Date 'dd-MM-yyyy' Time 'HH:mm:ss z");

                     // on below line we are creating a variable
                     // for current date and time and calling a simple date format in it.
                     String currentDateAndTime = sdf.format(new Date());

                     lf.setText("Last Time Full:" +currentDateAndTime);
                     tfFlag++;
                     tf.setText("Total Full: "+tfFlag);

                 }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });




    }

    public void gl(View view) {
        el=findViewById(R.id.el);
        a=findViewById(R.id.DU);




        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("location");
        // Read from the database
        myRef.child(a.getText().toString()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("TAG", "Value is: " + value);
                el.setText(value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });
    }

    public void sl(View view) {

        el=findViewById(R.id.el);
        a=findViewById(R.id.DU);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("location");
        myRef.child(a.getText().toString()).setValue(el.getText().toString());



    }
}